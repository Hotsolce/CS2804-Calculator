#ifndef CALCULATOR_H
#define CALCULATOR_H
#include <iostream>
#include "scanner.h"
#include <sstream>
#include <stack>
#include <queue>

class Calculator
{
    public:
    protected:
    private:
 };

#endif // CALCULATOR_H
